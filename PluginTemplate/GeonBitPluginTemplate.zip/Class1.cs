﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public static class GeonBitPluginInitializer
    {
        // get plugin name
        static public string GetName()
        {
            return "GeonBitPlugin";
        }

        // initialize plugin
        static public void Initialize()
        {
            // do init code
        }
    }
}
